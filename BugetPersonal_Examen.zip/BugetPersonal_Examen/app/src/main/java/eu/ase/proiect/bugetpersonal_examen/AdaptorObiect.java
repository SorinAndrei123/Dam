package eu.ase.proiect.bugetpersonal_examen;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class AdaptorObiect extends BaseAdapter {

    private Context context;
    private List<Model> modelList;
    private LayoutInflater inflater;

    private List<Integer> listCheckedObjects;


    public AdaptorObiect(Context applicationContext, List<Model> modelList) {
        this.context = applicationContext;
        this.modelList = modelList;
        this.listCheckedObjects = new ArrayList<Integer>();
    }

    public List<Integer> getListCheckedObjects() {
        return listCheckedObjects;
    }

    public void setListCheckedObjects(List<Integer> listCheckedObjects) {
        this.listCheckedObjects = listCheckedObjects;
    }

    @Override
    public int getCount() {
        return modelList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(inflater == null){
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }
        if(convertView == null){
            convertView = inflater.inflate(R.layout.obiect_display, null);
        }

        CheckBox checkbox = convertView.findViewById(R.id.cbObiect);
        checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(buttonView.isChecked())
                    listCheckedObjects.add(position);
                else if(!buttonView.isChecked() && listCheckedObjects.contains(position)){
                    listCheckedObjects.remove(position);
                }
            }
        });

        final String obiectDenumire= modelList.get(position).getDenumire();
        final String obiectSuma= String.valueOf(modelList.get(position).getSuma());
        final String obiectTip= modelList.get(position).getCont();

        TextView denumireTV, sumaTV, contTV;

        denumireTV=convertView.findViewById(R.id.tvDenumire);
        sumaTV=convertView.findViewById(R.id.tvSuma);
        contTV=convertView.findViewById(R.id.tvTip);

        denumireTV.setText(obiectDenumire);
        sumaTV.setText(obiectSuma);
        contTV.setText(obiectTip);

        return convertView;
    }
}
