package eu.ase.proiect.bugetpersonal_examen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class AdaugaModel extends Activity {

    public static final String MODEL_KEY = "key";

    public static final String POSITION_KEY = "position";

    private Intent intent;

    private EditText et_denumire;
    private EditText et_suma;
    private Spinner spn_tip;
    private Button btn_adauga;
    private RadioGroup rg_cont;

    private int positionToUpdate = 0;

    //TimePicker tpOra;

    //private ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adauga_model);

        intent = getIntent();

        et_denumire =findViewById(R.id.et1);
        et_suma =findViewById(R.id.et2);
        spn_tip =findViewById(R.id.spn1);
        rg_cont =findViewById(R.id.rg);
        //=findViewById(R.id.timePicker);
        btn_adauga =findViewById(R.id.btn1);

//        ArrayList<String> arrayList = new ArrayList<String>();
//        arrayList.add("Mancare");
//        arrayList.add("Imbracaminte");
//        arrayList.add("Facturi");
//        arrayList.add("Distractii");
//
//        arrayAdapter= new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, arrayList);
//        spnTip.setAdapter(arrayAdapter);

        btn_adauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(validate()){

                    String denumire= et_denumire.getText().toString();

                    double suma= Double.valueOf(et_suma.getText().toString());

                    String tip= spn_tip.getSelectedItem().toString();

                    String cont="";
                    if(rg_cont.getCheckedRadioButtonId() == R.id.rb1)
                        cont = Cont.Economii.toString();
                    else if(rg_cont.getCheckedRadioButtonId() == R.id.rb2)
                        cont = Cont.Curent.toString();

                    //int ora = tpOra.getHour();

                    Model model = new Model(denumire, suma, tip, cont, 12);

                    //Intent intent = new Intent(AdaugaModel.this, MainActivity.class);

                    intent.putExtra(MODEL_KEY, model);

                    if(positionToUpdate != 0){
                        intent.putExtra(POSITION_KEY, positionToUpdate);
                    }

                    setResult(Activity.RESULT_OK, intent);

                    finish();

                }
            }

        });


        if(intent.hasExtra(MODEL_KEY)) {
            Model model = (Model) intent.getSerializableExtra(MODEL_KEY);

            if (model == null){
                return;
            }

            positionToUpdate = intent.getIntExtra(POSITION_KEY,-1);

            et_denumire.setText(String.valueOf(model.getDenumire()));

            et_suma.setText(String.valueOf(model.getSuma()));

            ArrayAdapter<String> array_spinner=(ArrayAdapter<String>)spn_tip.getAdapter();
            spn_tip.setSelection(array_spinner.getPosition(model.getTipCheltuiala()));

            if(model.getCont() ==  Cont.Economii.toString())
                rg_cont.check(R.id.rb1);
            else
                rg_cont.check(R.id.rb2);

        }
    }

    private boolean validate(){
        if(et_denumire.getText().toString().equals(""))
        {
            et_denumire.setError("Introduceti denumirea");
            return false;
        }
        else if(et_suma.getText().toString().equals("") || Integer.parseInt(et_suma.getText().toString())<1)
        {
            et_suma.setError("Introduceti suma");
            return false;
        }
        else if (rg_cont.getCheckedRadioButtonId() == -1){
            Toast.makeText(AdaugaModel.this, "Alegeti tipul contului", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}
