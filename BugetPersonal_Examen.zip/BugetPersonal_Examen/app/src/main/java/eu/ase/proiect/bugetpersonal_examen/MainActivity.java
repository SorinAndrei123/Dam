package eu.ase.proiect.bugetpersonal_examen;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;

import android.widget.GridView;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import eu.ase.proiect.bugetpersonal_examen.database.DatabaseManager;

import static eu.ase.proiect.bugetpersonal_examen.AdaugaModel.MODEL_KEY;

public class MainActivity extends AppCompatActivity {

    private static final int ADD_CODE = 1;
    private static final int UPDATE_CODE = 2;

    AdaptorObiect adaptorObiect;

    GridView gridView;

    List<Model> listModels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridView);

        listModels = new ArrayList<>();

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), AdaugaModel.class);
                intent.putExtra(AdaugaModel.MODEL_KEY, listModels.get(position));
                startActivityForResult(intent, UPDATE_CODE);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.meniu, menu);
        return true;
    }

    @SuppressWarnings("deprecation")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();
        switch (id) {
            case R.id.adauga:
                Intent intent = new Intent(getApplicationContext(), AdaugaModel.class);
                startActivityForResult(intent, 1);
                break;
            case R.id.actualizare:
                for (Model model : listModels) {
                    if (model.getSuma() < 50 && model.getTipCheltuiala() == "Facturi") {
                        model.setSuma(0);
                    }
                }
                notifyAdapter();
                break;
            case R.id.stergere:
                if (adaptorObiect.getListCheckedObjects().size() > 0) {
                    for (int i : adaptorObiect.getListCheckedObjects()){
                        listModels.remove(i);


                        ////DATABASE delete object/////////////////////////////////////////////////////////////
                        final DatabaseManager databaseManager = DatabaseManager.getInstance(this);
                        databaseManager.getObiectDAO().deleteObiect(listModels.get(i));
                    }

                    notifyAdapter();
                }
                break;
            case R.id.salvare:
                Context context = getApplicationContext();
                try {
                    FileWriter out = new FileWriter(new File(context.getFilesDir(), "objects.txt"));

                    for (Model model : listModels) {
                        out.write(model.toString());
                    }

                    out.close();
                } catch (IOException e) {
                    Log.e("login activity", "Cannot read file: " + e.toString());
                }
                break;
            case R.id.loadDB:

                ////DATABASE load ALL/////////////////////////////////////////////////////////////
                final DatabaseManager databaseManager = DatabaseManager.getInstance(this);
                listModels.removeAll(listModels);
                listModels.addAll(databaseManager.getObiectDAO().getAll());
                notifyAdapter();
                break;
            case R.id.sort:

                ////DATABASE load all SORTED/////////////////////////////////////////////////////////////
                final DatabaseManager databaseManager2 = DatabaseManager.getInstance(this);
                listModels.removeAll(listModels);
                listModels.addAll(databaseManager2.getObiectDAO().getAllSorted());
                notifyAdapter();
                break;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == ADD_CODE) {
                Model model = (Model) data.getSerializableExtra(MODEL_KEY);

                listModels.add(model);

                notifyAdapter();


                ////DATABASE insert/////////////////////////////////////////////////////////////
                final DatabaseManager databaseManager = DatabaseManager.getInstance(this);
                databaseManager.getObiectDAO().insertObiect(model);
            }
            if (requestCode == UPDATE_CODE) {

                Model model = (Model) data.getSerializableExtra(AdaugaModel.MODEL_KEY);

                int positionToUpdate = data.getIntExtra(AdaugaModel.POSITION_KEY, -1);

                listModels.remove(positionToUpdate);
                listModels.add(model);

                notifyAdapter();


                final DatabaseManager databaseManager = DatabaseManager.getInstance(this);
                ////DATABASE update/////////////////////////////////////////////////////////////
                databaseManager.getObiectDAO().updateObiect(model);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void notifyAdapter() {
        adaptorObiect = new AdaptorObiect(getApplicationContext(), listModels);
        gridView.setAdapter(adaptorObiect);
        adaptorObiect.notifyDataSetChanged();
    }
}
