package eu.ase.proiect.bugetpersonal_examen;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.Serializable;

enum Cont {Curent, Economii}

@Entity(tableName = "modele")
public class Model implements Serializable {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "modelId")
    private int modelId;

    private String denumire;

    @ColumnInfo(name ="suma")
    private double suma;

    private String tipCheltuiala;
    private String cont;
    private int ora;

    public Model(int modelId, String denumire, double suma, String tipCheltuiala, String cont, int ora) {
        this.modelId = modelId;
        this.denumire = denumire;
        this.suma = suma;
        this.tipCheltuiala = tipCheltuiala;
        this.cont = cont;
        this.ora = ora;
    }

    @Ignore
    public Model(String denumire, double suma, String tipCheltuiala, String cont, int ora) {
        this.denumire = denumire;
        this.suma = suma;
        this.tipCheltuiala = tipCheltuiala;
        this.cont = cont;
        this.ora = ora;
    }

    public int getModelId() {
        return modelId;
    }

    public void setModelId(int modelId) {
        this.modelId = modelId;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public double getSuma() {
        return suma;
    }

    public void setSuma(double suma) {
        this.suma = suma;
    }

    public String getTipCheltuiala() {
        return tipCheltuiala;
    }

    public void setTipCheltuiala(String tipCheltuiala) {
        this.tipCheltuiala = tipCheltuiala;
    }

    public String getCont() {
        return cont;
    }

    public void setCont(String cont) {
        this.cont = cont;
    }

    public int getOra() {
        return ora;
    }

    public void setOra(int ora) {
        this.ora = ora;
    }

    @Override
    public String toString() {
        return "Model{" +
                "denumire='" + denumire + '\'' +
                ", suma=" + suma +
                ", tipCheltuiala='" + tipCheltuiala + '\'' +
                ", cont='" + cont + '\'' +
                ", ora=" + ora +
                '}';
    }
}
