package eu.ase.proiect.bugetpersonal_examen.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import eu.ase.proiect.bugetpersonal_examen.Model;


///////////////////////////////////////////

    ///NU UITA SA ADAUGI implementation
       // implementation 'androidx.room:room-runtime:2.0.0'
      //  annotationProcessor 'androidx.room:room-compiler:2.0.0'
///////////////////////////////////////////


@Database(entities = {Model.class}, version = 1, exportSchema = false)
public abstract class DatabaseManager extends RoomDatabase{

    private static final String DB_NAME = "obiect_DB";
    private static DatabaseManager databaseManager;

    public static DatabaseManager getInstance(Context context) {
        if (databaseManager == null) {
            synchronized (DatabaseManager.class) {
                if (databaseManager == null) {
                    databaseManager = Room.databaseBuilder(context, DatabaseManager.class, DB_NAME)
                            .allowMainThreadQueries()
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return databaseManager;
    }

    public abstract ObiectDAO getObiectDAO();

}
