package eu.ase.proiect.bugetpersonal_examen.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import eu.ase.proiect.bugetpersonal_examen.Model;

@Dao
public interface ObiectDAO {

    @Insert
    void insertObiect(Model model);

    @Update
    void updateObiect(Model model);

    @Delete
    void deleteObiect(Model model);

    @Query("Select * from modele")
    List<Model> getAll();

    @Query("Select * from modele ORDER BY suma DESC ")
    List<Model> getAllSorted();

//    @Query("Select distinct autor from obiecte")
//    public String[] getAutorDB();

    @Query("Select count(*) from modele")
    int getNumberOfObjectsStoredInDB();

    @Query("Delete from modele")
    void deleteAll();

}
